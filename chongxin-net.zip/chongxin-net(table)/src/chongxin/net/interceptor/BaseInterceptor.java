package chongxin.net.interceptor;

import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import chongxin.net.entity.MyUser;

public class BaseInterceptor implements HandlerInterceptor {
	
	private static Logger logger=LoggerFactory.getLogger(BaseInterceptor.class);

	
	
	@SuppressWarnings("rawtypes")
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object arg2) throws Exception {
		
		System.out.println("来到了拦截器第一个方法");		
//		MyUser u = new MyUser();
//		u=(MyUser) request.getSession().getAttribute("user");
//		System.out.println("本次登录的用户名为："+u.getUsername());
		System.out.println("存储在session 中的用户信息的（用户名是）："+request.getSession().getAttribute("user"));
		if(request.getSession().getAttribute("user") == null)
		{
			System.out.println("该用户非法登录");
            request.getRequestDispatcher("Login.jsp").forward(request, response);
			return true;

		}		
		logger.info("请求路径============================{}", request.getRequestURI());
		Enumeration names = request.getParameterNames();

		while (names.hasMoreElements()) {
			String name = (String) names.nextElement();
			String[] values = request.getParameterValues(name);
			for (String value : values) {
				value = cleanXSS(value);
			}
		}
		return true;
	}
	
	@Override
	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		System.out.println("来到了拦截器第三个方法");
	}

	@Override //改方法可以改变数据
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
		System.out.println("来到了拦截器第二个方法");
	}
	
	
	private static String cleanXSS(String value) {
		value = value.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
		value = value.replaceAll("%3C", "&lt;").replaceAll("%3E", "&gt;");
		value = value.replaceAll("\\(", "&#40;").replaceAll("\\)", "&#41;");
		value = value.replaceAll("%28", "&#40;").replaceAll("%29", "&#41;");
		value = value.replaceAll("'", "&#39;");
		value = value.replaceAll("eval\\((.*)\\)", ""); 
		value = value.replaceAll("[\\\"\\\'][\\s]*javascript:(.*)[\\\"\\\']", "\"\"");
		value = value.replaceAll("script", "");
		return value;
	}
	
	
	
	
}