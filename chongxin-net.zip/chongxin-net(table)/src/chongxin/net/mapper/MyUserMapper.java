package chongxin.net.mapper;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import chongxin.net.entity.Item;
import chongxin.net.entity.MyUser;

public interface MyUserMapper {

	int regist(MyUser user);
		
	List<Map> login(MyUser user);
	
	List<MyUser> findUsers();
	
	int deleteUser(int id);
	
	MyUser findUser(int id);
	
	int reUserUpdate(MyUser user);

	List<Item> getAllGoods();

}
