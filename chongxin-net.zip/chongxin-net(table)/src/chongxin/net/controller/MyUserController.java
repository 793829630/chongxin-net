package chongxin.net.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.auth0.jwt.internal.org.bouncycastle.asn1.ocsp.Request;

import chongxin.net.entity.Item;
import chongxin.net.entity.MyUser;
import chongxin.net.service.MyUserService;

@Controller
public class MyUserController {
	
	@Resource
	private MyUserService myUserService;
	
	@RequestMapping("/reUserUpdate")
	public String reUserUpdate(HttpServletResponse response,MyUser user)throws IOException{
		System.out.println("要修改的用户的id 是："+user.getId());
		int result = myUserService.reUserUpdate(user);
		if (result == 1)
	{
			System.out.println("成功");
		}
		else{
			System.out.println("失败！"+result);
		}
		return "redirect:getUsers";
	}
	
	
	
	
	@RequestMapping("/userRegister")
	public String regist(HttpServletResponse response,MyUser user)throws IOException{
		System.out.println("用户名："+user.getUsername()+"密码"+user.getPassword()+"性别"+user.getSex());
		int regist = myUserService.regist(user);
	
	    if (regist ==1)
	    {
	    	return "login";
	    }
	    else{
	    	return "404";
	    }
	  
	}
	
	
	@RequestMapping("/userLogin")
	public String login(HttpServletResponse response,HttpServletRequest requset,MyUser user)throws IOException{
		//首先判断用户是否选择使用Cookies
		String [] isUseCookies = requset.getParameterValues("isUseCookie");
		if (isUseCookies!=null&&isUseCookies.length>0)
		{
			//把用户名和密码保存在Cookie 里面
			String username = requset.getParameter("username");
			String password = requset.getParameter("password");
			Cookie usernameCookie = new Cookie("username",username);
			Cookie passwordCookie = new Cookie("password",password);
			usernameCookie.setMaxAge(60*60*24*15);//15天内保存用户名和密码
			passwordCookie.setMaxAge(60*60*24*15);
			response.addCookie(usernameCookie);
			response.addCookie(passwordCookie);
			System.out.println("已经保存了cookies 的值，用户名是"+usernameCookie.getValue()+"和密码"+passwordCookie.getValue());
		}
		else
		{
			Cookie[] cookies = requset.getCookies();
			if (cookies!=null&&cookies.length>0)
			{
				for(Cookie c : cookies)
				{
					if (c.getName().equals("username")||c.getName().equals("password"))
					{
						c.setMaxAge(0);//设置该Cookie 失效
						response.addCookie(c);//重新保存
					}
				}
			}
		}
		System.out.println("进入登录后台！");
		// 用Session保存用户信息	    
		
		List<Map> login = myUserService.login(user);
		if (login.size()!=0)
		{
			requset.getSession().setAttribute("user",user);	
			return "redirect:getUsers";			
		}
		else
		{
			System.out.println("------操作失败-----");
			return "404";
		}
    }

	@RequestMapping("/getUsers")
	public String getUsers(Model model){
		System.out.println("就这么神奇的过来了！！！");
		List<MyUser> users = myUserService.findUsers();
		System.out.println("得到的第三个用户的名字是"+users.get(2));
		if(users.size()!=0){
			System.out.println("------操作成功-----");
			System.out.println(users);
			model.addAttribute("list", users);
			return "success";
		}
		else
		{
			System.out.println("------操作失败-----");
			return "404";
		}
	}
	
	//得到商品
	@RequestMapping("/getAllGoods")
	public String getAllGoods(Model model){
		System.out.println("！！！！！！！！！！！！！！！！得到商品类型");
		List<Item> list = (ArrayList<Item>) myUserService.getAllGoods();
		if (list.size()!=0)
		{
			System.out.println("----得到商品集合-----");
			System.out.println(list);
		//	model.addAttribute("items", list);
			return "main";
			
		}
		else{
			System.out.println("-----得到用户集合失败-----");
			return null;
		}
		
//		
	}
	
	@RequestMapping("/deleteUser")
	public void deleteUser(HttpServletResponse response,HttpServletRequest requset)throws IOException{
	
		String Str = requset.getParameter("userid");
		
		int id = Integer.valueOf(Str);
		int result = myUserService.delete(id);
		PrintWriter out = response.getWriter();
		if (result==1)
		{ 
			out.write("1");	 //1代表删除成功
		}
		else
		{
			out.write("2"); //2代表删除失败
		}
		out.close();		
	}
	
	@RequestMapping("/updateUser")
	public String updateUser(HttpServletRequest request,int id)throws IOException{	
		   MyUser user = myUserService.findUser(id);	
		   
		   request.setAttribute("user", user);
		   
		   return "Update";
	
	}
	
}
