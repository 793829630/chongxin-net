/*package chongxin.net.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import chongxin.net.entity.MyUser;
import chongxin.net.service.MyUserService;

@Controller
public class MyUserController {
	
	@Resource
	private MyUserService myUserService;
	
	@RequestMapping("/userRegister")
	public void regist(HttpServletResponse response,MyUser user)throws IOException{
		int regist = myUserService.regist(user);
	    PrintWriter out = response.getWriter();
	    if (regist ==1)
	    {
	    	out.print("注册成功");
	    }
	    else{
	    	out.print("注册失败");
	    }
	    out.close();
	}
	
	
	@RequestMapping("/userLogin")
	public String login(HttpServletResponse response,MyUser user,Model model)throws IOException{
		System.out.println("进入登录后台！");
		List<Map> login = myUserService.login(user);
		PrintWriter out = response.getWriter();
		if (login.size()!=0)
		{
			//登陆成功
			System.out.println("------操作成功-----");
//			String username = user.getUsername();
//			model.addAttribute("user",username);
			//登陆成功后获取所有用户列表
//			for (MyUser myuser : users) {
//				String username = myuser.getUsername();
//				String password = myuser.getPassword();
//			}
//			System.out.println(users.toString());
			return "redirect:getUsers";
		}
		else
		{
			System.out.println("------操作失败-----");
			return "404";
		}
    }
	
	/**
	 * 查找所有用户
	 * @param model
	 * @return
	 */

/*	public String getUsers(Model model){
		List<MyUser> users = myUserService.findUsers();
		if(users.size()!=0){
			System.out.println("------操作成功-----");
			model.addAttribute("users", users);
			return "index";
		}
		else
		{
			System.out.println("------操作失败-----");
			return "404";
		}
	}
}*/
