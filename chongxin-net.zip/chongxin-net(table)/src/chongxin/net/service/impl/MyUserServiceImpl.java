package chongxin.net.service.impl;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import chongxin.net.entity.Item;
import chongxin.net.entity.MyUser;
import chongxin.net.mapper.MyUserMapper;
import chongxin.net.service.MyUserService;

@Service
public class MyUserServiceImpl implements MyUserService{
	
	@Resource
	private MyUserMapper sysuserdao;
	
	
	public int regist(MyUser user){
		
		System.out.println("用户名："+user.getUsername()+"密码"+user.getPassword()+"性别"+user.getSex());
		return sysuserdao.regist(user);
	}



	public List<Map> login(MyUser user) {
		System.out.println("进入登录后台！服务处");
		return sysuserdao.login(user);
	}


	public List<MyUser> findUsers() {
		// TODO Auto-generated method stub
		return sysuserdao.findUsers();
	}


	@Override
	public int delete(int id) {
		// TODO Auto-generated method stub
		//System.out.println("进入后台 ，服务处实现！！！！得到id:"+id);
		return sysuserdao.deleteUser(id);
	}


	@Override
	public MyUser findUser(int id) {
		// TODO Auto-generated method stub
		return sysuserdao.findUser(id);
		
	}
	@Override
	public int reUserUpdate(MyUser user){
		// TODO Auto-generated method stub
		System.out.println(" 到了服务处！！！！要修改的用户的id 是："+user.getId());
		return sysuserdao.reUserUpdate(user);
	}


	@Override
	public List<Item> getAllGoods() {
		// TODO Auto-generated method stub
		System.out.println("----来到了服务层----");
		return sysuserdao.getAllGoods();
	}

}
