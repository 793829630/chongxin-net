package chongxin.net.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import chongxin.net.entity.Item;
import chongxin.net.entity.MyUser;

public interface MyUserService {
	//注册
	int regist(MyUser user); 
	//登录
	List<Map> login(MyUser user);
	//查找所有用户
	List<MyUser> findUsers();
	//删除用户
	int delete(int id);
	//查找一个用户
	MyUser findUser(int id);
	//修改
	int reUserUpdate(MyUser user);
	//得到所有商品
	List<Item>getAllGoods();
}


