package chongxin.net.utils;

import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;

public class PrintExtendFun {
	/**
	 * 将List转成JSON字符串
	 * @param SD
	 * @return
	 */
	public static String jsonToString(List<?> SD){
		
		return JSONArray.fromObject(SD).toString();
	}
	
	/**
	 * 将Map转成JSON字符串
	 * @param SD
	 * @return
	 */
	public static String jsonToString(Map<String,Object> SD){
		
		return JSONArray.fromObject(SD).toString();
	}
	/**
	 * 将对象转成字符串
	 * @param SD
	 * @return
	 */
	public static String jsonToString(Object SD){
		return JSONArray.fromObject(SD).toString();
	}
	
	/**
	 * 将字符串数组转成字符串
	 * @param SD
	 * @return
	 */
	public static String jsonToString(String[] SD){
		return JSONArray.fromObject(SD).toString();
	}
}
