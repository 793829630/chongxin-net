package chongxin.net.utils;

import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

import sl.commons.action.FileDownload;
import sl.commons.report.excel.SimpleExcelParam;
import sl.commons.report.poi.PoiExcelHelper;

public class ExlExport {
	
	/**
	 * 
	 * @param titleArray 表头
	 * @param rows  每行内容
	 * @param fileName 不带后缀的文件名称，支持中文
	 * @param sheetName 页签名称
	 * @param title 第一行标题名称
	 * @param response
	 */
	public void excelExport(String[] titleArray,List<String[]> rows,String fileName,String sheetName,String title,HttpServletResponse response){
			//简单表头
			SimpleExcelParam sep = new SimpleExcelParam();
			sep.setFileName(fileName);
			sep.setSheetName(sheetName);
			sep.setTitle(title);
			sep.setHeaders(titleArray);
			sep.setAligns(new String[]{"left","left"});
			sep.setRows(rows);
			fileName = sep.getFileName() + "." + FileDownload.SUFFIX_EXCEL;
			try {
				OutputStream os = FileDownload.getOutputStream(response, FileDownload.CONTENT_TYPE_EXCEL, fileName);
				HSSFWorkbook wb = PoiExcelHelper.createSimpleHSSFWorkbook(sep);
				wb.write(os);
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e.getMessage());
			}
	}
	
	 public static String getStringVal(HSSFCell cell) {
	        switch (cell.getCellType()) {
	        case Cell.CELL_TYPE_BOOLEAN:
	            return cell.getBooleanCellValue() ? "TRUE" : "FALSE";
	        case Cell.CELL_TYPE_FORMULA:
	            return cell.getCellFormula();
	        case Cell.CELL_TYPE_NUMERIC:
	            cell.setCellType(Cell.CELL_TYPE_STRING);
	            return cell.getStringCellValue();
	        case Cell.CELL_TYPE_STRING:
	            return cell.getStringCellValue();
	        default:
	            return "";
	        }
	    }

}
