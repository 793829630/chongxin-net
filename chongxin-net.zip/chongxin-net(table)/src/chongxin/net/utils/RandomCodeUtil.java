package chongxin.net.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.UUID;


public class RandomCodeUtil {

	
	private static final String RAND_CHARS = "0123456789abcdefghigklmnopqrstuvtxyzABCDEFGHIGKLMNOPQRSTUVWXYZ";
    
    
    private static Random random = new Random();
    
    private static final SimpleDateFormat DATE_PATH_SDF = new SimpleDateFormat("yyyyMMddss");
    
    
    
    public static enum CodeCategory {
        commodity("comm");
        private String path;
    
        CodeCategory(String path) {
            this.path = path;
        }
        public String getPath() {
            return path;
        }
    }
    
    /**
     * 
     * @Description: 生产CODE
     * @param @param prefix
     * @param @return   
     * @return String  
     * @throws
     * @author hmq
     * @date 2017年9月28日
     */
    public static String getUCode(CodeCategory prefix){
    	StringBuffer sbf=new StringBuffer(prefix.getPath());
    	sbf.append(DATE_PATH_SDF.format(new Date()))
    	.append(RandomCodeUtil.getRandStr(4, 2));
    	return sbf.toString();
    }
    
    
    /**
     * 产生[0-max)范围的随机数
     * @param max 最大范围
     * @return
     * @author Frank.Hou
     */
    public static int rand(int max){
        return random.nextInt(max);
    }
    
    /**
     *产生[min-max)范围的随机数
     *如果@param min>=max 直接返回 min
     *如果 min<max && min<0 则返回[0-max)范围的随机数 
     * @param min 最小范围
     * @param max 最大范围
     * @return 生成的随机数
     * @author Frank.Hou
     */
    public static int rand(int min, int max){
        if(min<max){
            if(min>0){
                return rand(max-min)+min;
            }else{
                return rand(max);
            }
        }else{
            return min;
        }
    }
    /**
     * 
     * 返回长度为length的随机字符串
     * @param length 要生成随机字符串的长度
     * @param randType==0,则包括所有的字符的字符串,randType==1，返回字母串, randType==2 返回数字串
     * @return 长度为length的随机字符串
     * @author Frank.Hou
     */
    public static String getRandStr(int length, int randType) {
        StringBuffer hash = new StringBuffer(length);
        if(randType==1) {//返回字母串
            for (int i = 0; i < length; i++) 
                hash.append(RAND_CHARS.charAt(10+random.nextInt(52)));
        }else if(randType==2) {//返回数字串
            for (int i = 0; i < length; i++) 
                hash.append(RAND_CHARS.charAt(random.nextInt(10)));
        }else{
            for (int i = 0; i < length; i++) 
                hash.append(RAND_CHARS.charAt(random.nextInt(62)));
        }
        return hash.toString();
    }
   
   
   
   /**
    *  生成唯一标识
    */
   public static String getUUID(){
       return UUID.randomUUID().toString().replace("-", "");
   }
	
	
}
