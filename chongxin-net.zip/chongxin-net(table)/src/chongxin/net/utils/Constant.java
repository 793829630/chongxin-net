package chongxin.net.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * 常量类
 * @author admin
 */

public class Constant {
	/**
	 * 设置用户登陆有效时间30分钟
	 */
	public static Long TIME_LINESS = 30l;
	
	/**
	 * 系统日志保存位置
	 */
	public static String LOGADDRESS = "D:\\apache-tomcat-7.0.53\\logs\\";
	
	/**
	 * 登陆用户信息key
	 */
	public static String LOGIN_UER_KEY = "userInfo";
	/**
	 * 前端会员登陆用户信息key
	 */
	public static String LOGIN_MEMBER_KEY = "memberInfo";
	/**
	 * 前端会员登陆用户详情KEY
	 */
	public static String LOGIN_MEMBER_DETAIL_KEY = "memberInfo_detail";
	/**
	 * 前端会员注册使用验证码
	 */
	public static String MEMBER_NOTE_CODE = "noteCode";
	
	/**
	 * 用户操作权限
	 */
	public static String USER_OPERATION_POWER = "operation";
	
	/**
	 * 进入前端首页
	 */
	public static String LOGIN_PAGE_METHOD = "front-home";
	
	/**
	 * 进入后台登陆首页
	 */
	public static String LOGIN_BACK_PAGE = "login-page";
	/**
	 * 短信发送账号
	 */
	public static String NOTE_ACC = "N1015433";
	/**
	 * 短信发送密码
	 */
	public static String NOTE_PWD = "rlzXUYI4Rb659d";
	/**
	 * 短信发送链接前缀
	 */
	public static String NOTE_URL = "http://smssh1.253.com";
	/**
	 * 短信签名
	 */
	public static String NOTE_SIGNATURE = "【253云通讯】";
	/**
	 * 用户对表的可见权限
	 */
	public static String USER_FIELD_POWER = "userFieldPower";
	
	/**
	 * 进入微信登录页
	 */
	public static String LOGIN_WX_PAGE_METHOD = "ww-login";
	
	/**
	 * 会员签到获取积分数量
	 */
	public static Integer MEMBER_SIGN_INTEGRAL = 30;
	
	/**
	 * 图片上传路径前缀
	 */
	public static String PIC_ADDRESS_PRE = "http://api.ctq100.com";
	
	/**
	 * 微信token验证//3TaJXl7uJB9FkSEJMET7XiX2Yc2d7ZtKbSRDEyjOutb
	 */
	public static String WX_TOKEN = "LZYXweixin0713";//lfmlz360
	/**
	 * 旭飞测试号ID
	 */
	public static String APP_ID = "wxefaa7f6f81c63cd0";//wx401142b719911c9c
	/***
	 * 旭飞测试号
	 */
	public static String APP_SECRET = "76699f4da2a377688a36740c0decf40b";//1e84a0a1951463958dafda9fdfdf5583
	
	public static Integer API_PAGE_SIZE = 10; //api接口分页每页条数
	
	public static final String[] CONTROLLER_METHOD = {
		"customer",
		"salesman",
		"excel",
		"orderInfo",
		"user",
		"area",
		"visit",
		"cityarea",
		"salesman",
		"salesmanInfo",
		"order",
		"visitcustomer",
		"engineer",
		"userrole",
		"organization",
		"norms",
		"clinicinfo",
		"fr_sale",
		"news",
		"ww-"
	};
	public static Boolean checkUrl(String strs){
		for(int i = 0;i<Constant.CONTROLLER_METHOD.length;i++){        
	        if(Constant.CONTROLLER_METHOD[i].contains(strs)){            
	            return true;       
	         }  
	     }   
			return false;
	}
	
	/**
	 * 判断及重置登陆有效时间
	 * @param request
	 * @return
	 */
	public static Boolean checkUserTimeliness(HttpServletRequest request,HttpServletResponse response){
		return null;
		//存入会话session 
//        HttpSession session = request.getSession(true); 
//        Engineer userinfo = (Engineer) session.getAttribute(Constant.LOGIN_UER_KEY);
//        if(userinfo!=null){
//        	Long starttime = userinfo.getTimeliness();
//        	Long ms = DateUtil.startTimeToEndTime(starttime);
//        	if(ms<Constant.TIME_LINESS){
//        		JSONObject json = new JSONObject();
//        		userinfo.setTimeliness(System.currentTimeMillis());
//        		session.setAttribute(Constant.LOGIN_UER_KEY, userinfo);
//        		if(userinfo.getLoginmark()=="Y"){
//        			try {
//        				json.put("uname", URLEncoder.encode(userinfo.getUiUsername(),"UTF-8"));
//        			} catch (UnsupportedEncodingException e) {
//        				// TODO Auto-generated catch block
//        				e.printStackTrace();
//        			}
//        			json.put("pwd", userinfo.getUiPwdRoot());
//        			json.put("times", userinfo.getTimeliness());
//        			Cookie cookie = new Cookie(Constant.LOGIN_UER_KEY,json.toString());  
//        			cookie.setMaxAge(60*60*24*15);//保留15天  
//        			response.addCookie(cookie);
//        		}
//        		return true;
//        	}
//        }
		
		//存入会话session 
//        HttpSession session = request.getSession(true); 
//        Smjmanagementinfo userinfo = (Smjmanagementinfo) session.getAttribute(Constant.LOGIN_UER_KEY);
//        if(userinfo!=null){
//        	Long starttime = userinfo.getTimeliness();
//        	Long ms = DateUtil.startTimeToEndTime(starttime);
//        	if(ms<Constant.TIME_LINESS){
//        		userinfo.setTimeliness(System.currentTimeMillis());
//        		session.setAttribute(Constant.LOGIN_UER_KEY, userinfo);
//        		return true;
//        	}
//        }
//		return false;
	}
}
