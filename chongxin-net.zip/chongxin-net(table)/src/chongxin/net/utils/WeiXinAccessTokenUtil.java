package chongxin.net.utils;

import java.io.IOException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.springframework.util.StringUtils;

public class WeiXinAccessTokenUtil {
    /** 
     * 
     * 获取微信access_token 
     * <功能详细描述> 
     * @param appid 
     * @param secret 
     * @return 
     * @see [类、类#方法、类#成员] 
     */  
    public static GetAccessTokenRsp getWeiXinAccessToken(String appid,String secret){  
        if(StringUtils.isEmpty(appid)|| StringUtils.isEmpty(secret)){  
            return null;  
        }  
        GetAccessTokenRsp getAccessTokenRsp = new GetAccessTokenRsp();  
        try{  
            String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid="+appid+"&secret="+secret;  
            HttpClient httpClient = new HttpClient();  
            GetMethod getMethod = new GetMethod(url);  
            int execute = httpClient.executeMethod(getMethod);  
            System.out.println("execute:"+execute);  
            String getResponse = getMethod.getResponseBodyAsString();  
            getAccessTokenRsp.setAccessToken(getResponse);  
        }catch (IOException e){  
            e.printStackTrace();  
        }  
        System.out.println(getAccessTokenRsp);  
        return getAccessTokenRsp;  
    }  
    
    public static void main(String[] args) {
    	WeiXinAccessTokenUtil.getWeiXinAccessToken(Constant.APP_ID, Constant.APP_SECRET);
	}
}
