package chongxin.net.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
@SuppressWarnings("unused")
public class MysqlBC{
	 	private static String USERNAME=getPprVue().getProperty("username");//数据库用户名  
	    private static String PASSWORD=getPprVue().getProperty("password");//数据库用户密码  
		private static String PORT=getPprVue().getProperty("dbport");//数据库开放端口  
	    private static String IP=getPprVue().getProperty("dbAddress");//数据库ip地址  
	    private static String DATABASENAME=getPprVue().getProperty("databaseName");//数据库名称  
	   // private static String DBPATH=getPprVue().getProperty("dbpath");//数据库安装路径
	    private static String SQLPATH=getPprVue().getProperty("sqlFilePath");//存储路径
	    private static String DBPATH= getSysPath()+"\\WEB-INF\\sqltool\\";
	    public static Map<String, String> backUpTableList = new ConcurrentHashMap<String, String>();
		public static Map<String, String> recoverTableList = new ConcurrentHashMap<String, String>();
		private static MysqlBC dd= new MysqlBC();
	    /**读取dbfh.properties 配置文件
		 * @return
		 * @throws IOException
		 */
		public static Properties getPprVue() {
			InputStream inputStream = MysqlUtil.class.getClassLoader().getResourceAsStream("dbfh.properties");
			Properties p = new Properties();
			try {
				p.load(inputStream);
				inputStream.close();
			} catch (IOException e) {
				//读取配置文件出错
				e.printStackTrace();
			}
			return p;
		}
		public static MysqlBC getDbFH(){
			return dd;
		}
	
		/**数据库备份命令字符串
		 * @param dbtype 数据库类型
		 * @param dbpaths 数据库的路径
		 * @param address 数据库连接地址
		 * @param username 用户名
		 * @param password 密码
		 * @param sqlpath 存储路径
		 * @param tableName 表名
		 * @param databaseName 数据库名
		 * @param ffilename 日期当路径和保存文件名的后半部分
		 * @return 完整的命令字符串
		 */
		public static String getExecStr(String tableName){
			  String ffilename = DateUtil.getSdfTimes();
			StringBuffer sb = new StringBuffer();
				sb.append(DBPATH);
				sb.append("mysqldump ");
				sb.append("--opt ");
				sb.append("-h ");
				sb.append(IP);
				sb.append(" ");
				sb.append("--user=");
				sb.append(USERNAME);
				sb.append(" ");
				sb.append("--password=");
				sb.append(PASSWORD);
				sb.append(" ");
				sb.append("--lock-all-tables=true ");
				sb.append("--result-file=");
				sb.append(SQLPATH);
				sb.append(("".equals(tableName)?DATABASENAME+"_"+ffilename:tableName+"_"+ffilename)+".sql");
				sb.append(" ");
				sb.append("--default-character-set=utf8 ");
				sb.append(DATABASENAME);
				sb.append(" ");
				sb.append(tableName);//当tableName为“”时，备份整库
			return sb.toString();
		}
		/**执行数据库备份入口
		 * @param tableName 表名
		 * @return
		 * @throws InterruptedException
		 * @throws ExecutionException
		 */
		public String backup(String tableName) throws InterruptedException, ExecutionException {
			if(null != backUpTableList.get(tableName)) return null;
			backUpTableList.put(tableName, tableName); 				// 标记已经用于备份(防止同时重复备份,比如备份一个表的线程正在运行，又发来一个备份此表的命令)
			ExecutorService pool = Executors.newFixedThreadPool(2); 
			Callable<Object> fhc = new DbBackUpCallable(tableName);	//创建一个有返回值的线程
			Future<Object> f1 = pool.submit(fhc); 					//启动线程
			String backstr = f1.get().toString(); 					//获取线程执行完毕的返回值
			pool.shutdown();										//关闭线程
			return backstr;
		}
		/**用于执行某表的备份(内部类)线程
		 * Callable 有返回值的线程接口
		 */
		class DbBackUpCallable implements Callable<Object>{
			String tableName = null;
			public DbBackUpCallable(String tableName){
				this.tableName = tableName;
			}
			@Override
			public Object call() {
				String commandStr = "";
				try {
					FileUtil.createDir(SQLPATH+"/DBback");
					commandStr = getExecStr(tableName); //命令语句
					Runtime cmd = Runtime.getRuntime();
					Process p = cmd.exec(commandStr);
					p.waitFor(); 
					return "ok";
				} catch (Exception e) {
					return "errer";
				}finally{
					backUpTableList.remove(tableName); // 最终都将解除
				}
				
			}
		}
		
		/**执行数据库还原入口
		 * @param tableName 表名
		 * @param sqlFilePath 备份文件存放完整路径
		 * @return
		 * @throws InterruptedException
		 * @throws ExecutionException
		 */
		public String recover(String tableName,String sqlFilePath) throws InterruptedException, ExecutionException {
			if(null != recoverTableList.get(tableName)) {
				return null;
			}
			recoverTableList.put(tableName, tableName); 							// 标记已经用于还原(防止同时重复还原,比如还原一个表的线程正在运行，又发来一个还原此表的命令)
			ExecutorService pool = Executors.newFixedThreadPool(2); 
			Callable<Object> fhc = new DbRecoverCallable(tableName,sqlFilePath);	//创建一个有返回值的线程
			Future<Object> f1 = pool.submit(fhc); 									//启动线程
			String backstr = f1.get().toString(); 									//获取线程执行完毕的返回值
			pool.shutdown();														//关闭线程
			return backstr;
		}
		/**用于执行某表或整库的还原(内部类)线程
		 * Callable 有返回值的线程接口
		 */
		class DbRecoverCallable implements Callable<Object>{
			String tableName = null;
			String sqlFilePath = null;
			public DbRecoverCallable(String tableName,String sqlFilePath){
				this.tableName = tableName;
				this.sqlFilePath = sqlFilePath;
			}
			@Override
			public Object call() {
				try {
				  	Runtime runtime = Runtime.getRuntime();
				  	String commandStr=DBPATH+"mysql -u"+USERNAME+" -p"+PASSWORD+" -h"+IP+" "+DATABASENAME+" <"+sqlFilePath;
				  	runtime.exec(new String[]{"cmd","/c",commandStr}); 
				  	return "ok";
				} catch (Exception e) {
					e.printStackTrace();
					return "errer";
				}finally{
					recoverTableList.remove(tableName); // 最终都将解除
				}
			}
			
		}
		public static String getSysPath() {
			String path = Thread.currentThread().getContextClassLoader()
					.getResource("").toString();
			String temp = path.replaceFirst("file:/", "").replaceFirst(
					"WEB-INF/classes/", "");
			String separator = System.getProperty("file.separator");
			String resultPath = temp.replaceAll("/", separator + separator);
			return resultPath;
		}
		
	
}