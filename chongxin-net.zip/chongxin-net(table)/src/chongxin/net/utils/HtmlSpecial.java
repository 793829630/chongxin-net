package chongxin.net.utils;

/**
 * ClassName: HtmlSpecial 
 * @Description: 字符转义
 * @author yokoboy
 * @date 2017年10月9日
 */
public class HtmlSpecial {
	
	
	/**
	 * @Description: html转义成字符串
	 * @param @param str
	 * @param @return   
	 * @return String  
	 * @throws
	 * @author yokoboy
	 * @date 2017年10月9日
	 */
	public  static String htmlspecialchars(String str) {
		str = str.replaceAll("&", "&amp;");
		str = str.replaceAll("<", "&lt;");
		str = str.replaceAll(">", "&gt;");
		str = str.replaceAll("\"", "&quot;");
		return str;
	}
	
	
	/**
	 * @Description: 字符串转移成html
	 * @param @param str
	 * @param @return   
	 * @return String  
	 * @throws
	 * @author yokoboy
	 * @date 2017年10月9日
	 */
	public static String charsspecialhtml(String str) {
		str = str.replaceAll("&amp;", "&");
		str = str.replaceAll("&lt;", "<");
		str = str.replaceAll("&gt;", ">");
		str = str.replaceAll("&quot;", "\"");
		return str;
	}
	
	

}
