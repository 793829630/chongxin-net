package chongxin.net.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class DateUtil {
	private static SimpleDateFormat sdf = null;
	private final static SimpleDateFormat sdfTimes = new SimpleDateFormat("yyyyMMddHHmmss");
	private final static SimpleDateFormat sdfDays = new SimpleDateFormat("yyyyMMdd");
	/**
	 * 获取YYYY格式
	 * @return
	 */
	public static String getSdfTimes() {
		return sdfTimes.format(new Date());
	}
	/**
	 * 获取YYYYMMDD格式
	 * @return
	 */
	public static String getDays(){
		return sdfDays.format(new Date());
	}
	/**
	 * 通常datestr类型转换，包含
	 * yyyy-MM-dd，yyyy年MM月dd日，yyyy/MM/dd
	 * @param dateStr
	 * @return
	 */
	public static Date getDateByString(String dateStr){
		String parten = "yyyy-MM-dd";
		if(dateStr != null && dateStr.indexOf("-") != -1 && dateStr.length() != 16){
			return getDateByString(dateStr, parten);
		}else if(dateStr != null && dateStr.indexOf("/") != -1){
			parten = "yyyy/MM/dd";
			return getDateByString(dateStr, parten);
		}else if(dateStr != null && dateStr.indexOf("年") != -1 && dateStr.indexOf("月") != -1){
			parten = "yyyy年MM月dd日";
			return getDateByString(dateStr, parten);
		}else if(dateStr != null && dateStr.length() == 8){
			parten = "yyyyMMdd";
			return getDateByString(dateStr, parten);
		}else if(dateStr != null && dateStr.length() == 16){
			System.out.println("------------日期----格-----式化---------------------");
			parten = "yyyy-MM-dd HH:mm";
			return getDateByString(dateStr, parten);
		}
		
		return getDateByString(dateStr, parten);
	}
	
	/**
	 * 获取当前时间的日期
	 * @param parten 格式，如yyyy-MM-dd,yyyy年MM月dd日
	 * @return
	 */
	public static int getCurrDAY(Date date) {
		if(date==null){
			date = new Date();
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.DATE);
	}
	
	/**
	 * 获取当前时间的月份
	 * @param parten 格式，如yyyy-MM-dd,yyyy年MM月dd日
	 * @return
	 */
	public static int getCurrMonth(Date date) {
		if(date==null){
			date = new Date();
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.MONTH)+1;
	}
	
	/**
	 * 获取当前时间的月份
	 * @param parten 格式，如yyyy-MM-dd,yyyy年MM月dd日
	 * @return
	 */
	public static int getCurrYear(Date date) {
		if(date==null){
			date = new Date();
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.YEAR);
	}
		
	/**
	 * 通过固定格式转换datestr
	 * @param dateStr
	 * @param parten 格式，如yyyy-MM-dd,yyyy年MM月dd日
	 * @return
	 */
	public static Date getDateByString(String dateStr, String parten){
		if(dateStr != null){
			sdf = new SimpleDateFormat(parten);
			try {
				return sdf.parse(dateStr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	/**
	 * 添加天数
	 * @param date
	 * @param day
	 * @return
	 */
	public static Date add(Date date,Integer day){
		Calendar calendar = Calendar.getInstance();
    	calendar.setTime(date);
    	calendar.add(Calendar.DATE, day);
		return calendar.getTime();
	}
	
	/**
	 * 添加天数
	 * @param date
	 * @param day
	 * @return
	 */
	public static Date minusDay(Date date,Integer day){
		Calendar calendar = Calendar.getInstance();
    	calendar.setTime(date);
    	calendar.set(Calendar.DATE, date.getDate()-day);
		return calendar.getTime();
	}
	
	/**
	 * 添加月份
	 * <br>
	 * 注意：该方法会修改原始值
	 * @param date
	 * @param month 月份周期
	 * @return
	 */
	public static Date addMonth(Date date,Integer month){
		Calendar calendar = Calendar.getInstance();
    	calendar.setTime(date);
    	calendar.add(Calendar.MONTH, month);
		return calendar.getTime();
	}
	
	/**
	 * 添加年份
	 * @param date 日期
	 * @param year 年份
	 * @return
	 */
	public static Date addYear(Date date,Integer year){
		Calendar calendar = Calendar.getInstance();
    	calendar.setTime(date);
    	calendar.add(Calendar.YEAR, year);
		return calendar.getTime();
	}
	
	/**
	 * 计算日期距离当前月份指定日期
	 * @param date
	 * @param day
	 * @return
	 */
	public static Date distanceDay(Date date,Integer day){
		Calendar calendar = Calendar.getInstance();
    	calendar.setTime(date);
    	calendar.set(Calendar.DATE, day);
    	return calendar.getTime();
	}
	
	/**
	 * date转换格式字符串
	 * @param date 时间
	 * @param parten 转换格式
	 * @return
	 */
	public static String getStrByDate(Date date, String parten){
		SimpleDateFormat sdf = new SimpleDateFormat(parten);
		String result = "";
		if(date != null) result = sdf.format(date); 
		return result;
	}
	
	/**
	 * date转换格式字符串,默认格式yyyy-MM-dd
	 * @param date 时间 
	 * @return
	 */
	public static String toString(Date date){
		return getStrByDate(date, "yyyy-MM-dd");
	}
	
	/**  
     * 计算两个日期之间相差的天数  (算头不算尾)
     * @param smdate 开始时间
     * @param bdate  结束时间 
     * @return 相差天数 
     * @throws ParseException  
     */    
    public static int daysBetween(Date smdate,Date bdate) throws ParseException{    
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		smdate = sdf.parse(sdf.format(smdate));
		bdate = sdf.parse(sdf.format(bdate));
		Calendar cal = Calendar.getInstance();
		cal.setTime(smdate);
		long time1 = cal.getTimeInMillis();
		cal.setTime(bdate);
		long time2 = cal.getTimeInMillis();
		long between_days = (time2 - time1) / (1000 * 3600 * 24);
		return Integer.parseInt(String.valueOf(between_days)); 
    }   
    
    /**
     * 判断日期date 是否在startDate和endDate之间
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @param date 需要判断的日期
     * @param isEquals 是否区间等于true 可以等于,false 不等于区间首尾
     * @return
     */
    public static boolean ifBetween(Date startDate,Date endDate,Date date,boolean isEquals){
    	// 判断是否是包含区间等于
    	if(isEquals){
    		if(startDate.equals(date) || endDate.equals(date)){
        		return true;
        	}
    	}
    	// 判断日期区间
    	if(startDate.before(date) && endDate.after(date)){
			return true;
		}
    	return false;
    }
    
    /**
     * 两个区间之间的比较
     * @param startDate 外 区间开始日期
     * @param endDate 外 区间结束日期
     * @param bStartdate 内 区间开始日期
     * @param bEnddate 内 区间结束日期
     * @param isEquals 是否等于
     * @param parse 日期格式化
     * @return
     */
    public static boolean ifBetween(Date startDate,Date endDate,Date bStartdate,Date bEnddate,boolean isEquals){
    	return ifBetween(startDate, endDate, bStartdate, bEnddate, isEquals, "yyyy-MM-dd");
    }
    
    /**
     * 两个区间之间的比较
     * @param startDate 外 区间开始日期
     * @param endDate 外 区间结束日期
     * @param bStartdate 内 区间开始日期
     * @param bEnddate 内 区间结束日期
     * @param isEquals 是否等于
     * @param parse 日期格式化
     * @return
     */
    public static boolean ifBetween(Date startDate,Date endDate,Date bStartdate,Date bEnddate,boolean isEquals,String parse){
    	// 判断是否是包含区间等于
    	if(isEquals){
    		if(formatDate(startDate,parse).getTime() <= formatDate(bStartdate,parse).getTime() && 
    				formatDate(endDate,parse).getTime() >= formatDate(bEnddate,parse).getTime()){
        		return true;
        	}
    	}else{
    		if(formatDate(startDate,parse).getTime() < formatDate(bStartdate,parse).getTime() && 
    				formatDate(endDate,parse).getTime() > formatDate(bEnddate,parse).getTime()){
        		return true;
        	}
    	}
    	return false;
    }
    
    /**
     * 判断日期date 是否在startDate和endDate之间（包含即<= ,>= ）
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @param date 需要判断的日期
     * @return
     */
    public static boolean ifBetween(Date startDate,Date endDate,Date date){
    	return ifBetween(startDate, endDate, date, true);
    }
    
    /**
     * 判断日期date 是否在startDate和endDate之间（只判断日期部分）（包含即<= ,>= ）
     * @param startDate
     * @param endDate
     * @param date
     * @return
     */
    public static boolean ifBetweenDate(Date startDate,Date endDate,Date date){
    	return ifBetween(formatDate(startDate), formatDate(endDate), formatDate(date), true);
    }
    
    /**
     * 将日期对象格式化yyyy-MM-dd，去掉时分秒
     * @param date
     * @return
     */
    public static Date formatDate(Date date){
		return formatDate(date, "yyyy-MM-dd");
	}
    
    /**
     * 日期格式化,将日期对象格式化成指定对象
     * @param date
     * @param parse
     * @return
     */
    public static Date formatDate(Date date,String parse){
		if(date != null){
			sdf = new SimpleDateFormat(parse);
			try {
				return sdf.parse(sdf.format(date));
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
    
    /**
     * 获取日期对象的时间部分的毫秒数（取时间部分的毫秒数）
     * @param date
     * @return
     */
    public static long getTimeInMillis(Date date){
    	Calendar cal = Calendar.getInstance();
		cal.setTime(formatDate(date, "yyyy-MM-dd HH:mm:ss"));
		// 当前时：HOUR_OF_DAY-24小时制；HOUR-12小时制  
	    int hour = cal.get(Calendar.HOUR_OF_DAY);  
	    // 当前分  
	    int minute = cal.get(Calendar.MINUTE);  
	    // 当前秒  
	    int second = cal.get(Calendar.SECOND); 
	    return ((hour*60+minute)*60+second)*1000;
    }
    
    /**
     * 比较日期的time是否相等
     * @param date 
     * @param date2
     * @param parse 日期比较格式
     * @return
     */
    public static boolean compareDate(Date date,Date date2,String parse){
    	if(DateUtil.formatDate(date,parse).getTime() == DateUtil.formatDate(date2,parse).getTime()){
    		return true;
    	}
    	return false;
    }
    
    /**
     * 比较日期的time是否相等
     * <br>默认格式yyyy-MM-dd
     * @param date
     * @param date2
     * @return
     */
    public static boolean compareDate(Date date,Date date2){
    	if(DateUtil.formatDate(date).getTime() == DateUtil.formatDate(date2).getTime()){
    		return true;
    	}
    	return false;
    }
    
    /**
     * 将制定的开始和结束日期按照类型（1=年,2=月,3=季度）分段
     * <br>从小到大的顺序排列
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @param type （1年，2月）
     * @return
     */
    public static Map<Date,Date> section(Date startDate,Date endDate,int type) throws ParseException{		
    	int month = 0;
    	// 设定一年后
		if(type == 1){
			month = 12;
		}else if(type == 2){
			month = 1;
		}else if(type == 3){
			month = 3;
		}
		return sectionMonth(startDate, endDate, month);
    }
    
    /**
     * 按照指定的日期和周期记性时间分段
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @param month 月份周期
     * @param incomeday 周期日
     * @return
     * @throws ParseException
     */
	@SuppressWarnings("deprecation")
	public static Map<Date,Date> sectionMonth(Date startDate,Date endDate,int month,int incomeday) throws ParseException{		
    	// 按顺序录入
    	LinkedHashMap<Date,Date> map = new LinkedHashMap<Date, Date>();
    	// 时间区间设定
    	Date s = (Date) startDate.clone();
		Date e = null;
		
    	if(month == 3||month == 6||month == 12){
    		natureGetSetionMap(map, startDate, endDate, incomeday, month);	
    	}else{
    		// 补全不满足一个计算周期
    		Calendar calendar = Calendar.getInstance();
    		calendar.setTime((Date) s.clone());
			// 开始的日期天数大于计息天数,第一笔为开始天数
			if(s.getDate() < incomeday){
				calendar.set(Calendar.DATE, incomeday);
				calendar.add(Calendar.MONTH, month - 1);
				e = calendar.getTime();
			}else{
				calendar.add(Calendar.MONTH, month);
				calendar.set(Calendar.DATE, incomeday);
				e = calendar.getTime();
			}
			// 添加
			map.put(s, e);
			s = (Date) e.clone();
			map.putAll(sectionMonth(s, endDate, month));
    	}
		return map;
    }
	
	/**
     * 按照指定的日期和自然周期记性时间分段
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @param month 月份周期（1月,3季,6半年,12年）
     * @param incomeday 周期日
     * @return
     * @throws ParseException
     */
	public static Map<Date,Date> sectionNaturalMonth(Date startDate,Date endDate,int month,int incomeday) throws ParseException{		
    	// 按顺序录入
    	LinkedHashMap<Date,Date> map = new LinkedHashMap<Date, Date>();
		// 锁定开始日期
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		// 获取当前日期的月份
		int thisMonth = calendar.get(Calendar.MONTH)+1;
		// 获取当前日期对应周期的余值
		int d = thisMonth%month;
		// 判断开始日是否大于收取日
		if(calendar.get(Calendar.DATE) > incomeday){
			// 设定第一个周期的结束日期
			calendar.set(Calendar.DATE, incomeday);
			// 结束月 = 固定周期月 = 周期月 - 当前月周期余值
			calendar.add(Calendar.MONTH, (month-d));
		}else{
			// 设定第一个周期的结束日期
			calendar.set(Calendar.DATE, incomeday);
			// 补全月 = 当前月所属第几区（即在月，季，半年，年中的区间）的下一区间
			// 乘以周期
			int q = 0;
			if(thisMonth%month == 0){
				q = (thisMonth/month) * month;
			}else{
				q = (thisMonth/month + 1) * month;
			}
			calendar.set(Calendar.MONTH, q-1);
		}
		
		Date e = calendar.getTime();
		Date s = startDate;
		// 存储周期
		map.put(s, e);
		// 循环下个周期
		while (calendar.getTime().getTime() < endDate.getTime()) {
			calendar.set(Calendar.DATE, incomeday);
			calendar.add(Calendar.MONTH, month);
			s = (Date) e.clone();
			e = calendar.getTime();
			// 如果周期截止日期超过结束日期，使用结束日期
			if(e.getTime() >  endDate.getTime()){
				e = endDate;
				map.put(s, e);
				break;
			}
			map.put(s, e);
		}
		return map;
    }
	
	
	
	/**
	 * 生成自然季度，月，年的区间
	 * @param map 存储区间
	 * @param startDate 开始日期
	 * @param endDate 截止日期
	 * @param incomeday 收息日
	 * @param intervals 3，季度：6，月：9，年
	 */
	private static void natureGetSetionMap(LinkedHashMap<Date,Date> map,Date startDate,Date endDate,int incomeday, int intervals){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime((Date) startDate.clone());

		Date e = null;
		
		if((startDate.getMonth()+1)%intervals == 0 && startDate.getDate() < incomeday){
			//如果当月就是自然季，半年，年，的最后一个月，切日期小于收息日，则第一笔收息计划，为本月
		}else{
			calendar.add(Calendar.MONTH, startDate.getMonth()+(intervals-(startDate.getMonth()+1)%intervals));	
		}
		calendar.set(Calendar.DATE, incomeday);
		e = calendar.getTime();
		
		//若结束日期，超出截止日期，退出
		if(e.getTime() > endDate.getTime()){
			e = endDate;
			return;
		}
		//放置区间开始结束日期
		map.put(startDate, e);
		
		//下一次的开始日期，等于本次的结束日期
		startDate = (Date) e.clone();
		
		natureGetSetionMap(map, startDate, endDate, incomeday,intervals);
	}
	
    /**
     * 将指定的开始和结束日期按照月份分割
     * <br>区间是带有重叠的
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @param month 月份
     * @return
     * @throws ParseException
     */
	public static LinkedHashMap<Date,Date> sectionMonth(Date startDate,Date endDate,int month) throws ParseException{		
    	// 按顺序录入
    	LinkedHashMap<Date,Date> map = new LinkedHashMap<Date, Date>();
    	// 时间区间设定
    	Date s = (Date) startDate.clone();
		Date e = null;
		int begin=0;//区间开始
		int end=0;//区间结束
		Date k=(Date) startDate.clone();//日期始终从开始日期开始算
		// 开始周期计算
		while (startDate.getTime() < endDate.getTime()) {
			end=end+month;
			// 设定一年后
			e = DateUtil.addMonth(k, end);
			// 满足区间
			if(e.getTime() <= endDate.getTime()){
				map.put((Date)s.clone(), (Date)e.clone());
				//s = (Date) e.clone();
				begin+=month;
				s=DateUtil.addMonth(k, begin);
			}else{
				map.put((Date)s.clone(), (Date)endDate.clone());
				break;
			}
		}
		return map;
    }
	
	/**
	 * 根据开始日期和结束日期生成区间,返回结束日期集合（结束日期集合）
	 * @param startDate 开始日期
	 * @param endDate 结束日期
	 * @param month 月份周期
	 * @param incomeday 收取天数
	 * @return
	 */
	public static List<Date> sectionMonthList(Date startDate,Date endDate,int month,int incomeday){
		// 按顺序录入
    	List<Date> sectionList = new ArrayList<Date>();
    	// 时间区间设定
    	Date s = (Date) startDate.clone();
		Date e = null;
		// 补全不满足一个计算周期
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		// 开始的日期天数大于计息天数,第一笔为开始天数
		if(s.getDate() < incomeday){
			calendar.set(Calendar.DATE, incomeday);
			calendar.add(Calendar.MONTH, month - 1);
			e = calendar.getTime();
		}else{
			calendar.add(Calendar.MONTH, month);
			calendar.set(Calendar.DATE, incomeday);
			e = calendar.getTime();
		}
		// 添加
		sectionList.add(e);
		s = (Date) e.clone();
		// 开始周期计算
		while (startDate.getTime() < endDate.getTime()) {
			// 设定一年后
			e = DateUtil.addMonth(s, month);
			// 满足区间
			if(e.getTime() <= endDate.getTime()){
				sectionList.add((Date)e.clone());
				s = (Date) e.clone();
			}else{
				sectionList.add((Date)endDate.clone());
				break;
			}
		}
		return sectionList;
	}
	
	/**
	 * 日期分段统计(区间的结束日期=下一区间的开始日期)
	 * @param startDate 开始日期
	 * @param sectionMonthList 结束日期集合
	 * @return
	 */
	public static LinkedHashMap<Date,Date> sectionMonth(Date startDate,List<Date> sectionMonthList){
		LinkedHashMap<Date,Date> linkedHashMap = new LinkedHashMap<Date, Date>();
		Date update = startDate;
    	for (Date date : sectionMonthList) {
    		linkedHashMap.put(update, date);
    		update = date;
		}
    	return linkedHashMap;
	}
	
	   /** 
	     * 取得月第一天 
	     *  
	     * @param date 
	     * @return 
	     */  
	    public static Date getFirstDateOfMonth(Date date) {  
	        Calendar c = Calendar.getInstance();  
	        c.setTime(date);  
	        c.set(Calendar.DAY_OF_MONTH, c.getActualMinimum(Calendar.DAY_OF_MONTH));  
	        return c.getTime();  
	    }  
	  
	    /** 
	     * 取得月最后一天 
	     *  
	     * @param date 
	     * @return 
	     */  
	    public static Date getLastDateOfMonth(Date date) {  
	        Calendar c = Calendar.getInstance();  
	        c.setTime(date);  
	        c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));  
	        return c.getTime();  
	    }  
	  
	    //生成自然月周期区间
		public static Map<Date,Date> NatureSection(Date startDate,Date endDate,int month){
			// 按顺序录入
			LinkedHashMap<Date,Date> map = new LinkedHashMap<Date, Date>();
			// 锁定开始日期
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(startDate);
			// 获取当前日期的月份
			int thisMonth = calendar.get(Calendar.MONTH)+1;
			// 获取当前日期对应周期的余值
			int d = thisMonth%month;
			// 补全月 = 当前月所属第几区（即在月，季，半年，年中的区间）的下一区间
			// 乘以周期
			int q = 0;
			if(thisMonth%month == 0){
				q = (thisMonth/month) * month;
			}else{
				q = (thisMonth/month + 1) * month;
			}
			calendar.set(Calendar.MONTH, q-1);
			
			Date e = getLastDateOfMonth(calendar.getTime());
			Date s = startDate;
			Date v=add(e,1);
			// 存储周期
			map.put(s, v);
			// 循环下个周期
			while (e.getTime() < endDate.getTime()) {
				s = add(e,1);
				e = getLastDateOfMonth(addMonth(e,month));
				v = add(e,1);
				// 如果周期截止日期超过结束日期，使用结束日期
				if(e.getTime() >=  endDate.getTime()){
					e = endDate;
					map.put(s, e);
					break;
				}
				map.put(s, v);
			}
			return map;
		} 
		
		
		//根据天数生成周期区间
		public static Map<Date,Date> DaySection(Date startDate,Date endDate,int day){
			// 按顺序录入
			LinkedHashMap<Date,Date> map = new LinkedHashMap<Date, Date>();
			Date s = startDate;
			Date e= add(startDate,day);
			// 循环下个周期
			while (s.getTime() < endDate.getTime()) {
				// 如果周期截止日期超过结束日期，使用结束日期
				if(e.getTime() >  endDate.getTime()){
					e = endDate;
					map.put(s, e);
					break;
				}
				map.put(s, e);
				s=e;
				e=add(s,day);
			}
			return map;
		}
		
		
		
	/**
	 * 添加秒数
	 * @param date 日期
	 * @param second 添加秒数
	 * @return
	 */
	public static Date addSecond(Date date,int second){
		Calendar calendar = Calendar.getInstance();
    	calendar.setTime(date);
    	calendar.add(Calendar.SECOND, second);
		return calendar.getTime();
	}
	
	/**
	 * 获取当前日期0:00:00到指定时间部分的秒数
	 * @param date
	 * @return
	 */
	public static int getDistanceZeroSecond(Date date){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		// 时
		int hh = calendar.get(Calendar.HOUR);
		// 分
		int mm = calendar.get(Calendar.MINUTE);
		// 秒
		int ss = calendar.get(Calendar.SECOND);
		return (hh * 60 + mm)*60+ss;
	}
	/**
	 * 获取当前时间距离传入时间的分钟数
	 * @param start 精确到毫秒的时间戳
	 * @return
	 */
	public static Long startTimeToEndTime(Long start){
		Long end = System.currentTimeMillis();
		Long ms = end-start;
		int ss = 1000;  
        int mi = ss * 60;  
        int hh = mi * 60;  
        int dd = hh * 24;
        
        long day = ms / dd;  
        long hour = (ms - day * dd) / hh;  
        long minute = (ms - day * dd - hour * hh) / mi;  
        long second = (ms - day * dd - hour * hh - minute * mi) / ss;  
        long milliSecond = ms - day * dd - hour * hh - minute * mi - second * ss;  

        String strDay = day < 10 ? "0" + day : "" + day; //天  
        String strHour = hour < 10 ? "0" + hour : "" + hour;//小时  
        String strMinute = minute < 10 ? "0" + minute : "" + minute;//分钟  
        String strSecond = second < 10 ? "0" + second : "" + second;//秒  
        String strMilliSecond = milliSecond < 10 ? "0" + milliSecond : "" + milliSecond;//毫秒  
        strMilliSecond = milliSecond < 100 ? "0" + strMilliSecond : "" + strMilliSecond;  
         
		return minute;
	}
	
	/**
	 * 将当前日期进行格式转换
	 * @param format
	 * @return
	 */
	public static String dateToStr(String format){
		SimpleDateFormat df = new SimpleDateFormat(format); 
		return df.format(new Date());
	}
	
	/**
	 * 将当前日期进行格式转换
	 * @param format
	 * @return
	 */
	public static Date strToDate(String format,String date){
		SimpleDateFormat df = new SimpleDateFormat(format); 
		Date dates = null;
		try {
			dates = df.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dates;
	}
	
	 /** 
     * 根据开始时间和结束时间返回时间段内的时间集合 
     *  
     * @param beginDate 
     * @param endDate 
     * @return List 
     */  
    public static List<Date> getDatesBetweenTwoDate(Date beginDate, Date endDate) {  
        List<Date> lDate = new ArrayList<Date>();  
        lDate.add(beginDate);// 把开始时间加入集合  
        Calendar cal = Calendar.getInstance();  
        // 使用给定的 Date 设置此 Calendar 的时间  
        cal.setTime(beginDate);  
        boolean bContinue = true;  
        while (bContinue) {  
            // 根据日历的规则，为给定的日历字段添加或减去指定的时间量  
            cal.add(Calendar.DAY_OF_MONTH, 1);  
            // 测试此日期是否在指定日期之后  
            if (endDate.after(cal.getTime())) {  
                lDate.add(cal.getTime());  
            } else {  
                break;  
            }  
        }  
        lDate.add(endDate);// 把结束时间加入集合  
        return lDate;  
    }  

	public static void main(String[] args) throws ParseException {
		
		//System.out.println(DateUtil.startTimeToEndTime(calendar.getTimeInMillis()));
//		Date startDate=new Date();
//		Date endDate = addMonth(startDate, 1);
//		System.out.println(DateUtil.getStrByDate(startDate,"yyyy-MM-dd"));
//		System.out.println(DateUtil.getStrByDate(endDate,"yyyy-MM-dd"));
//		List<Date> list = getDatesBetweenTwoDate(startDate,endDate);
//		for (Date date : list) {
//			System.out.println(DateUtil.getStrByDate(date,"yyyy-MM-dd"));
//		}
		System.out.println(strToDate("yyyy-MM", "2017-08"));
		System.out.println();
	}
}

