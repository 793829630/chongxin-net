package chongxin.net.utils;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 * Created by 和闯闯 on 2017/6/12.
 */
public class CodeUtils {

    public static char[] getChar(){
        char[] chrs = "1234567890qwertyuiopasdfghjklzxcvbnm".toCharArray();
        Random r = new Random();
        char[] chr = new char[4];
        for (int i = 0; i < chr.length; i++) {
            chr[i] = chrs[r.nextInt(35)];
        }
        return chr;
    }

    public static BufferedImage getImage(char[] chr){

        BufferedImage buffer = new BufferedImage(90, 40, BufferedImage.TYPE_INT_RGB);


        Graphics g = buffer.getGraphics();


        g.setColor(Color.BLACK);
        g.drawRect(0, 0, 90, 20);


        g.setColor(Color.WHITE);
        g.drawString(chr[0] + "", 10, 25);
        g.drawString(chr[1] + "", 30, 25);
        g.drawString(chr[2] + "", 50, 25);
        g.drawString(chr[3] + "", 70, 25);


        g.dispose();

        return buffer;
    }
}
