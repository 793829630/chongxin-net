package chongxin.net.utils;


public class ApiPagerUtil {

	private Integer count; //总条数
	private Integer pageSize = Constant.API_PAGE_SIZE; //每页条数
	private Integer pageNum = 1;  //当前页数
	private Integer begin; //起始索引
	private Integer haveMore; //是否是最后一页
	private Integer pageCount; //总页数
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getPageNum() {
		return pageNum;
	}
	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}
	public Integer getBegin() {
		return begin;
	}
	public void setBegin(Integer begin) {
		this.begin = begin;
	}
	public Integer getHaveMore() {
		return haveMore;
	}
	public void setHaveMore(Integer haveMore) {
		this.haveMore = haveMore;
	}
	public Integer getPageCount() {
		return pageCount;
	}
	public void setPageCount(Integer pageCount) {
		this.pageCount = pageCount;
	}
	public ApiPagerUtil() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ApiPagerUtil(Integer count, Integer pageNum) {
		super();
		this.count = count;
		this.pageCount = this.count%this.pageSize==0?this.count/this.pageSize:this.count/this.pageSize+1;
		//pageCount=(int)(count+pageSize)/pageSize;
		if(pageNum!=null){
			this.pageNum = pageNum<this.pageCount?pageNum:this.pageCount;
		}
		this.begin = (this.pageNum-1)*this.pageSize;
		this.haveMore = this.pageNum<this.pageCount?1:0;
	}
	
	
	
}
