package chongxin.net.api;

import net.sf.json.JSONArray;

public class testJSON {

	public static void main(String[] args) {
		String jsonStr = "[{\"PROBLEM_ID\":5,\"SCORE\":5},{\"PROBLEM_ID\":6,\"SCORE\":5},{\"PROBLEM_ID\":7,\"SCORE\":5},{\"PROBLEM_ID\":8,\"SCORE\":5},{\"PROBLEM_ID\":9,\"SCORE\":5},{\"PROBLEM_ID\":10,\"SCORE\":5},{\"PROBLEM_ID\":11,\"SCORE\":5}]";

		JSONArray jsonArray = JSONArray.fromObject(jsonStr);
		
		for (int i = 0; i < jsonArray.size(); i++) {
			System.out.println("第"+i+"次循环-----------------------------------------------------------");
			System.out.println("题目id: "+jsonArray.getJSONObject(i).getString("PROBLEM_ID"));
			System.out.println("题目分数： : "+jsonArray.getJSONObject(i).getString("SCORE"));
		}

	}

}
